
package imat;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import se.chalmers.cse.dat216.project.IMatDataHandler;

public class MainViewController implements Initializable {

    @FXML
    Button profileButton;
    @FXML
    TextField SearchPane;
    @FXML
    Button personalInfoButton;
    @FXML
    Button adressInfoButton;
    @FXML
    TextField NameField;
    @FXML
    TextField PasswordField;
    @FXML
    TextField EmailField;
    @FXML
    TextField numberField;
    @FXML
    Button changeNameButton;
    @FXML
    Button changePasswordButton;
    @FXML
    Button changeEmailButton;
    @FXML
    Button changeNumberButton;

    @FXML
    Label pathLabel;
    @FXML
    Button backButton;
    @FXML
    Button buyNewItemsButton;

    IMatDataHandler iMatDataHandler = IMatDataHandler.getInstance();

    public void initialize(URL url, ResourceBundle rb) {

        String iMatDirectory = iMatDataHandler.imatDirectory();

        //pathLabel.setText(iMatDirectory);
    }

}