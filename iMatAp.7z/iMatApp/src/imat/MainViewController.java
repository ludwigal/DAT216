package imat;

import javafx.fxml.Initializable;

import java.awt.*;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.AnchorPane;
import se.chalmers.cse.dat216.project.IMatDataHandler;
import se.chalmers.cse.dat216.project.Product;
import se.chalmers.cse.dat216.project.ShoppingCart;
import se.chalmers.cse.dat216.project.ShoppingItem;

public class MainViewController implements Initializable {

    @FXML
    Label pathLabel;

    @FXML
    FlowPane productsFlowPane;

    @FXML
    AnchorPane betalAnchor;
    @FXML
    AnchorPane dummyPane;

    @FXML
    FlowPane swagPane;



    List swag = new ArrayList();

    IMatDataHandler iMatDataHandler = IMatDataHandler.getInstance();
    final ShoppingCart shoppingCart = iMatDataHandler.getShoppingCart();
    public void initialize(URL url, ResourceBundle rb) {
        shoppingCart.addProduct(iMatDataHandler.getProduct(43));
        String iMatDirectory = iMatDataHandler.imatDirectory();
        Object s = iMatDataHandler.getShoppingCart();
        /*List<Product> swag = new ArrayList<>();
        List<ShoppingItem> products = shoppingCart.getItems();
        for (ShoppingItem product: products) {
            Product cum = product.getProduct();
            swag.add(cum);
        }

         */
        updateProductList(iMatDataHandler.getProducts());
        productsFlowPane.getChildren().add(dummyPane);

        //swag.add(iMatDataHandler.getProduct(62));

        updateswaglist();

        //iMatDataHandler.getShoppingCart().addShoppingCartListener(this);

        //updateProductList(iMatDataHandler.getProducts());
        //updateBottomPanel();

        //setupAccountPane();

        // Load the NamePanel and add it to dynamicPane
        // This shows how one can develop a view in a separate
        // FXML-file and then load it into on of the panes in the main interface
        // There is an fxml file NamePanel.fxml and a corresponding class NamePanel.java
        // Simply create a new NamePanel object and add it as a child of dynamicPane
        // The NamePanel holds a reference to the main controller (this class)
        //AnchorPane namePane = new NamePanel(this);
        //dynamicPane.getChildren().add(namePane);
    }

    private void updateswaglist() {
        List<ShoppingItem> products = shoppingCart.getItems();

        for (ShoppingItem product: products) {
            Product cum = product.getProduct();
            swagPane.getChildren().add(new ProductPanel(cum, ew MainPanel()));

        }

    }


    private void updateProductList(List<Product> products) {

        System.out.println("updateProductList " + products.size());
        productsFlowPane.getChildren().clear();

        for (Product product : products) {

            productsFlowPane.getChildren().add(new ProductPanel(product, iMatDataHandler));
        }

    }
    @FXML
    public void closeRecipeView() {
        betalAnchor.toFront();
    }
}