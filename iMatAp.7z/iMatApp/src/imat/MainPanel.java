
package imat;

import java.io.IOException;
import java.net.URL;
import java.util.*;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.FlowPane;
import se.chalmers.cse.dat216.project.*;

public class MainPanel extends AnchorPane {

    @FXML
    Label pathLabel;
    @FXML private AnchorPane productDetailsPane;
    @FXML private ImageView productDetailsImage;
    @FXML private Label productDetailsName;
    @FXML private Label productDetailsPrice;
    @FXML FlowPane productFlowPane;
    @FXML FlowPane shoppingCartFlowPane;

    @FXML
    private Button ShoppingCartLabel;

    @FXML ToggleButton startButton;

    @FXML
    private ToggleButton breadButton;

    @FXML
    private ToggleGroup categoryButtons;

    @FXML
    private Label categoryLabel;

    @FXML
    private ToggleButton dairyButton;

    @FXML
    private ToggleButton drinkButton;

    @FXML
    private ToggleButton favouriteButton;

    @FXML
    private ToggleButton fishButton;

    @FXML
    private ToggleButton fruitButton;

    @FXML
    private ToggleButton meatButton;

    @FXML
    private ToggleButton pastaButton;

    @FXML
    private Button productDetailsBuyButton;


    @FXML
    private ScrollPane productListPane;

    @FXML
    private ToggleButton spiceButton;

    @FXML
    private ToggleButton sweetButton;

    @FXML
    private ToggleButton vegetableButton;

    @FXML
    private TextField searchTextField;

    @FXML Button searchButton;


    private Map<String, ProductPanel> productPanelMap = new HashMap<String, ProductPanel>();
    private Map<String, ProductPanelRow> productPanelRowMap = new HashMap<String, ProductPanelRow>();
    private Map<String, ProductPanelSubcategory> productPanelSubcategoryMap = new HashMap<String, ProductPanelSubcategory>();

    private Map<String, CartProductPanel> cartProductPanelMap = new HashMap<String, CartProductPanel>();
    private final static double kImageWidth = 100.0;
    private final static double kImageRatio = 0.75;

    private Product product;

    IMatDataHandler iMatDataHandler = IMatDataHandler.getInstance();
    /*CreditCard creditCard = iMatDataHandler.getCreditCard();
    Customer customer = iMatDataHandler.getCustomer();
    ShoppingCart shoppingCart = iMatDataHandler.getShoppingCart();*/

    public MainPanel() {
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("imat_app.fxml"));
        fxmlLoader.setRoot(this);
        fxmlLoader.setController(this);
        try {
            fxmlLoader.load();
        } catch (IOException exception) {
            throw new RuntimeException(exception);
        }
        //List<Product> products = iMatDataHandler.findProducts("s");
        /*for(Product product : products){
            iMatDataHandler.addProduct(product);
        }*/
        /*for(Product product : iMatDataHandler.getProducts()) {
            System.out.println(product);
            ProductPanel productListItem = new ProductPanel(product, this);
            productPanelMap.put(product.getName(), productListItem);
        }
        */
        List<ProductCategory> categories = List.of(ProductCategory.values());
        for(ProductCategory category : ProductCategory.values()){
            System.out.println(category);
            ProductPanelRow panelRow = new ProductPanelRow(category, this);
            ProductPanelSubcategory panelSubcategory = new ProductPanelSubcategory(category, this);
            productPanelRowMap.put(String.valueOf(category), panelRow);
            productPanelSubcategoryMap.put(String.valueOf(category), panelSubcategory);
        }
        for(Product product : iMatDataHandler.getProducts()){
            System.out.println(product);
            ProductPanel panel = new ProductPanel(product, this);
            CartProductPanel cartPanel = new CartProductPanel(product, this);
            productPanelMap.put(String.valueOf(product), panel);
            cartProductPanelMap.put(String.valueOf(product), cartPanel);
        }

        categoryLabel.setText("Varor");
        updateProductListCategory(categories);
        String iMatDirectory = iMatDataHandler.imatDirectory();

        pathLabel.setText(iMatDirectory);

    }

    Map<String, ProductPanel> getProductPanelMap(){
        return productPanelMap;
    }
    private void updateProductListCategory(List<ProductCategory> categories){
        productFlowPane.getChildren().clear();
        for(int i = 0; i < categories.size(); i++) {
            productFlowPane.getChildren().add(productPanelRowMap.get(String.valueOf(categories.get(i))));
        }
    }
    private void updateProductListProduct(List<Product> products){
        productFlowPane.getChildren().clear();
        for(int i = 0; i < products.size(); i++) {
            productFlowPane.getChildren().add(productPanelMap.get(String.valueOf(products.get(i))));
        }
    }

    void showSubcategory(ProductCategory category){
        List<ProductCategory>categoryList = List.of(category);
        updateProductListCategory(categoryList);
        productFlowPane.getChildren().clear();
        for(int i = 0; i < categoryList.size(); i++) {
            productFlowPane.getChildren().add(productPanelSubcategoryMap.get(String.valueOf(categoryList.get(i))));
        }
        //productFlowPane.getChildren().clear();
        /*for(int i = 0; i < products.size(); i++){
            productFlowPane.getChildren().add(productPanelSubcategoryMap.get(String.valueOf(products.get(i))));
        }*/
    }

    private void populateProductDetailView(Product product) {
        productDetailsName.setText(product.getName());
        productDetailsImage.setImage(iMatDataHandler.getFXImage(product, kImageWidth, kImageWidth*kImageRatio));
        productDetailsPrice.setText(String.format("%.2f", product.getPrice()) + " " + product.getUnit());

    }
    public void openProductView(Product product) {
        this.product = product;
        populateProductDetailView(product);
        productDetailsPane.toFront();
    }
    @FXML
    public void closeProductView() {
        productListPane.toFront();
    }
    @FXML
    void toggleCategory(ActionEvent event) {
        List<ProductCategory> categories = new ArrayList<>();
        //List<Product> products = new ArrayList<>();
        if(event.getSource() == startButton){
            categories = List.of(ProductCategory.values());
            //products = iMatDataHandler.getProducts();
            //updateProductListProduct(products);
            categoryLabel.setText("Varor");
            //return;
        }
        else if(event.getSource() == favouriteButton){

            categoryLabel.setText("Favoriter");
        }
        else if(event.getSource() == vegetableButton){
            categories.add(ProductCategory.VEGETABLE_FRUIT);
            categories.add(ProductCategory.ROOT_VEGETABLE);
            categories.add(ProductCategory.CABBAGE);
            categories.add(ProductCategory.POD);
            categories.add(ProductCategory.NUTS_AND_SEEDS);
            categoryLabel.setText("Grönsaker");
        }
        else if(event.getSource() == fruitButton){
            categories.add(ProductCategory.FRUIT);
            categories.add(ProductCategory.BERRY);
            categories.add(ProductCategory.CITRUS_FRUIT);
            categories.add(ProductCategory.EXOTIC_FRUIT);
            categories.add(ProductCategory.MELONS);
            categoryLabel.setText("Frukt");
        }
        else if(event.getSource() == pastaButton){
            categories.add(ProductCategory.PASTA);
            categories.add(ProductCategory.POTATO_RICE);
            categoryLabel.setText("Pasta, Ris & Potatis");
        }
        else if(event.getSource() == breadButton){
            categories.add(ProductCategory.BREAD);
            categoryLabel.setText("Bröd");
        }
        else if(event.getSource() == dairyButton){
            categories.add(ProductCategory.DAIRIES);
            categoryLabel.setText("Mejeri & Ägg");
        }
        else if(event.getSource() == meatButton){
            categories.add(ProductCategory.MEAT);
            categoryLabel.setText("Kött & Fågel");
        }
        else if(event.getSource() == fishButton){
            categories.add(ProductCategory.FISH);
            categoryLabel.setText("Fisk & Skaldjur");
        }
        else if(event.getSource() == spiceButton){
            categories.add(ProductCategory.FLOUR_SUGAR_SALT);
            categories.add(ProductCategory.HERB);
            categoryLabel.setText("Kryddor");
        }
        else if(event.getSource() == sweetButton){
            categories.add(ProductCategory.SWEET);
            categoryLabel.setText("Sötsaker");
        }
        else if(event.getSource() == drinkButton){
            categories.add(ProductCategory.COLD_DRINKS);
            categories.add(ProductCategory.HOT_DRINKS);
            categoryLabel.setText("Dryck");
        }
        updateProductListCategory(categories);
    }
    @FXML
    void searchText(ActionEvent event){
        String text = searchTextField.getText();
        List<Product> foundProducts = iMatDataHandler.findProducts(text);
        updateProductListProduct(foundProducts);
        categoryButtons.selectToggle(null);
        categoryLabel.setText("Funna Varor");
    }
    @FXML
    private void handleAddAction(ActionEvent event) {
        System.out.println("Add " + product.getName());
        iMatDataHandler.getShoppingCart().addItem(new ShoppingItem(product));
        System.out.println(iMatDataHandler.getShoppingCart().getItems());
        System.out.println(iMatDataHandler.getShoppingCart().getTotal());
        updateCart();
    }
    void updateCart(){
        shoppingCartFlowPane.getChildren().clear();
        for(ShoppingItem item : iMatDataHandler.getShoppingCart().getItems()){
            shoppingCartFlowPane.getChildren().add(cartProductPanelMap.get(String.valueOf(item.getProduct())));
        }
    }
}