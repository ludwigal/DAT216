package imat;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import se.chalmers.cse.dat216.project.IMatDataHandler;

import java.io.IOException;

public class Betalning extends AnchorPane {

    private IMatDataHandler iMatDataHandler = IMatDataHandler.getInstance();

    private Listener sub;
    @FXML
    private Label nameLabel;

    @FXML
    private Label nummerLabel;


    @FXML
    private Label emailLabel;

    @FXML
    private Label adressLabel;


    @FXML
    private Label cardLabel;

    @FXML
    Label L08;

    @FXML
    Label L10;

    @FXML
    Label L12;

    @FXML
    Label L14;

    @FXML
    Label L16;

    @FXML
    Label L18;

    @FXML
    private Button bekButton;


    public Betalning(Listener sub) {

        this.sub = sub;
        iMatDataHandler.getCustomer().setFirstName("Swag");
        iMatDataHandler.getCustomer().setLastName("Swag");
        {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("Betalning.fxml"));
            fxmlLoader.setRoot(this);
            fxmlLoader.setController(this);
            try {
                fxmlLoader.load();
            } catch (IOException exception) {
                throw new RuntimeException(exception);
            }


        }


    }

    public void update(){
        nameLabel.setText(iMatDataHandler.getCustomer().getFirstName() + " " + iMatDataHandler.getCustomer().getLastName());
        nummerLabel.setText(iMatDataHandler.getCustomer().getPhoneNumber());
        adressLabel.setText(iMatDataHandler.getCustomer().getAddress());
        emailLabel.setText(iMatDataHandler.getCustomer().getEmail());
        cardLabel.setText(iMatDataHandler.getCreditCard().getCardNumber());
    }

    public void changePay() {
        sub.changePay();
    }

    public void persPressed(){
        this.sub.persPressed();


    }

    public void profilePressed() {
        sub.profilePressed();
    }

    public void bekPressed() {
        iMatDataHandler.placeOrder(true);
        System.out.println("Nähepp");
        System.out.println(iMatDataHandler.getOrders());
        sub.bekPressed();
    }

    @FXML
    public void tillbaka() {
        System.out.println("Swag");
        this.sub.tillbaka();
    }

    @FXML
    public void setTime08() {
        sub.timeSet("08.00-10.00");
    }


    @FXML
    public void setTime10() {
        sub.timeSet("10.00-12.00");
    }

    @FXML
    public void setTime12() {
        sub.timeSet("12.00-14.00");
    }

    @FXML
    public void setTime14() {
        sub.timeSet("14.00-16.00");
    }

    @FXML
    public void setTime16() {
        sub.timeSet("16.00-18.00");
    }

    @FXML
    public void setTime18() {
        sub.timeSet("18.00-20.00");
    }

    @FXML
    public void placeOrder(){
        iMatDataHandler.placeOrder(true);
        System.out.println("Jahopp");
        System.out.println(iMatDataHandler.getOrders());
        iMatDataHandler.shutDown();
    }

    }

