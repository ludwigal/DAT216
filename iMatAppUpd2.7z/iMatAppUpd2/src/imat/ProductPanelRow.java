/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package imat;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.FlowPane;
import se.chalmers.cse.dat216.project.IMatDataHandler;
import se.chalmers.cse.dat216.project.Product;
import se.chalmers.cse.dat216.project.ProductCategory;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 *
 * @author oloft
 */
public class ProductPanelRow extends AnchorPane {

    @FXML ImageView imageView;
    @FXML Label SubcategoryLabel;
    @FXML Label prizeLabel;
    @FXML FlowPane SubcategoryFlowPane;
    @FXML
    Button subcategoryButton;

    private Map<String, ProductPanelMain> productPanelMap = new HashMap<String, ProductPanelMain>();

    private MainPanel mainPanel;
    private IMatDataHandler iMatDataHandler = IMatDataHandler.getInstance();

    private ProductCategory category;

    private final static double kImageWidth = 100.0;
    private final static double kImageRatio = 0.75;

    public ProductPanelRow(ProductCategory categoryName, MainPanel mainPanel) {
        this.category = categoryName;
        this.mainPanel = mainPanel;
        //System.out.println("swag");
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("ProductPanelRow.fxml"));
        fxmlLoader.setRoot(this);
        fxmlLoader.setController(this);

        try {
            fxmlLoader.load();
        } catch (IOException exception) {
            throw new RuntimeException(exception);
        }
        for(Product product : iMatDataHandler.getProducts(categoryName)) {
            //System.out.println(product);
            ProductPanelMain productListItem = new ProductPanelMain(product, mainPanel);
            productPanelMap.put(product.getName(), productListItem);
        }
        //productPanelMap = mainViewController.getProductPanelMap();
        SubcategoryFlowPane.getChildren().clear();
        List<Product> products = mainPanel.iMatDataHandler.getProducts(categoryName);
        int size = 6;
        if (products.size() < 6){
            size = products.size();
        }
        for(int i = 0; i < size; i++) {
            SubcategoryFlowPane.getChildren().add(productPanelMap.get(products.get(i).getName()));
        }
        SubcategoryLabel.setText(String.valueOf(categoryName));
    }
    
    @FXML
    private void handleShowMoreAction() {
        /*SubcategoryFlowPane.getChildren().clear();
        List<Product> products = mainViewController.iMatDataHandler.getProducts(this.category);
        for(int i = 0; i < products.size(); i++) {
            SubcategoryFlowPane.getChildren().add(productPanelMap.get(products.get(i).getName()));
        }*/
        System.out.println("here");
        mainPanel.showSubcategory(this.category);

        /*mainViewController.productFlowPane.getChildren().clear();
        SubcategoryFlowPane.getChildren().clear();
        List<Product> products = mainViewController.iMatDataHandler.getProducts(category);
        for(int i = 0; i < products.size(); i++) {
            SubcategoryFlowPane.getChildren().add(productPanelMap.get(products.get(i).getName()));
        }
        System.out.println("Show: " + category);
        SubcategoryLabel.setText(String.valueOf(category));*/
    }
}
