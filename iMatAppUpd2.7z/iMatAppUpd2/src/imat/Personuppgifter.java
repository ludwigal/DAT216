package imat;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import se.chalmers.cse.dat216.project.IMatDataHandler;

import java.io.IOException;

public class Personuppgifter extends AnchorPane {

    @FXML
    private TextField adressTextField;
    @FXML
    private TextField postkodTextField;

    @FXML
    private TextField nameTextField;

    @FXML
    private TextField lastnameTextField;

    @FXML
    private TextField nummerTextField;

    @FXML
    private TextField emailTextField;
    @FXML
    private TextField stadTextField;

    private IMatDataHandler iMatDataHandler = IMatDataHandler.getInstance();

    private Listener sub;

    public Personuppgifter(Listener sub) {
        this.sub = sub;
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("PersonUppgifter.fxml"));
        fxmlLoader.setRoot(this);
        fxmlLoader.setController(this);
        try {
            fxmlLoader.load();
        } catch (
                IOException exception) {
            throw new RuntimeException(exception);
        }
        nameTextField.setText(iMatDataHandler.getCustomer().getFirstName());
        lastnameTextField.setText(iMatDataHandler.getCustomer().getLastName());
        adressTextField.setText(iMatDataHandler.getCustomer().getAddress());
        postkodTextField.setText(iMatDataHandler.getCustomer().getPostCode());
        stadTextField.setText(iMatDataHandler.getCustomer().getPostAddress());

    }

    public void update(){
        adressTextField.setText(iMatDataHandler.getCustomer().getAddress());
        postkodTextField.setText(iMatDataHandler.getCustomer().getPostCode());
        stadTextField.setText(iMatDataHandler.getCustomer().getPostAddress());

    }

    public void saveChange(){
        iMatDataHandler.getCustomer().setAddress(adressTextField.getText());
        iMatDataHandler.getCustomer().setPostCode(postkodTextField.getText());
        iMatDataHandler.getCustomer().setPostAddress(stadTextField.getText());
        iMatDataHandler.getCustomer().setFirstName(nameTextField.getText());
        iMatDataHandler.getCustomer().setLastName(lastnameTextField.getText());
        iMatDataHandler.getCustomer().setPhoneNumber(nummerTextField.getText());
        iMatDataHandler.getCustomer().setEmail(emailTextField.getText());
    }

    public void changeAdress(){
        iMatDataHandler.getCustomer().setAddress(adressTextField.getText());

    }

    public void changePostCode(){
        iMatDataHandler.getCustomer().setPostCode(postkodTextField.getText());

    }

    public void changeCity(){
        iMatDataHandler.getCustomer().setPostAddress(stadTextField.getText());
    }

    public void changeName(){
        iMatDataHandler.getCustomer().setFirstName(nameTextField.getText());
    }

    public void changeName2(){
        iMatDataHandler.getCustomer().setLastName(lastnameTextField.getText());
    }

    public void changeNumber(){
        iMatDataHandler.getCustomer().setPhoneNumber(nummerTextField.getText());
    }

    public void changeEmail(){
        iMatDataHandler.getCustomer().setEmail(emailTextField.getText());
    }

    public void tillbaka(){
        sub.tillbaka();

    }
    public void profilePressed(){
        sub.profilePressed();
    }
    public void homepagePressed(){sub.homepagePressed();}


}
