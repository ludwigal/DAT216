
package imat;

import java.awt.*;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import se.chalmers.cse.dat216.project.*;

public class MainViewController implements Initializable {



    @FXML
    AnchorPane betalAnchor;
    @FXML
    AnchorPane dummyPane;

    @FXML
    AnchorPane backPane;

    @FXML
    FlowPane swagPane;

    @FXML
    FlowPane baseFlowPane;

    private Pane view;

    private String time;

    private Node memoryView;

    private List<Node> memoryViewList = new ArrayList<>();



    IMatDataHandler iMatDataHandler = IMatDataHandler.getInstance();
    CreditCard creditcard = iMatDataHandler.getCreditCard();

    Listener sub = new Listener(this);
    final ShoppingCart shoppingCart = iMatDataHandler.getShoppingCart();

    private HistoryPanel historyPanel = new HistoryPanel(sub);
    private MainPanel mainPanel = new MainPanel(sub);

    private Varukorg cart = new Varukorg(sub);

    private Betalning betalning = new Betalning(sub);

    private Kortuppgifter kortuppgifter = new Kortuppgifter(sub);

    private Personuppgifter personuppgifter = new Personuppgifter(sub);

    private Profil profil = new Profil(sub);

    private Bekraftelse bekraftelse = new Bekraftelse(sub);
    enum view {
        homepage,
        varukorg,
        profil,
        betalning,
        kortuppgfiter,
        personuppgifter,
        bekraftelse
    }

    public void initialize(URL url, ResourceBundle rb) {
        this.memoryView = memoryView;
        this.memoryViewList = memoryViewList;
        baseFlowPane.getChildren().clear();
        //fillcontent(new Varukorg(iMatDataHandler.getProducts(), sub));
        System.out.println(iMatDataHandler.getShoppingCart().getItems());
        baseFlowPane.getChildren().add(mainPanel);
        this.memoryViewList.add(baseFlowPane.getChildren().get(0));

    }

    public void fillcontent(String content) {

        this.memoryViewList.add(baseFlowPane.getChildren().get(0));
        switchView(content);

    }

    public void tillbakaView(){
        mainPanel.updateCart();
        System.out.println(this.memoryViewList);
        Node c = this.memoryViewList.get(this.memoryViewList.size()-1);
        this.memoryViewList.remove(memoryViewList.size()-1);
        baseFlowPane.getChildren().clear();
        baseFlowPane.getChildren().add(c);

    }

    public void timeSet(String time){
        this.time = time;
        System.out.println(this.time);
    }

    private void switchView(String name)
    {

        switch (name)
        {
            case "history":
                baseFlowPane.getChildren().clear();
                baseFlowPane.getChildren().add(historyPanel);
                historyPanel.updateHistoryList();
                break;
            case "homepage":
                mainPanel.updateCart();
                baseFlowPane.getChildren().clear();
                baseFlowPane.getChildren().add(mainPanel);
                break;
            case "cart":
                cart.updateList();
                baseFlowPane.getChildren().clear();
                baseFlowPane.getChildren().add(cart);
                break;
            case "profil":
                baseFlowPane.getChildren().clear();
                baseFlowPane.getChildren().add(profil);
                break;
            case "kortuppgfiter":
                kortuppgifter.update();
                baseFlowPane.getChildren().clear();
                baseFlowPane.getChildren().add(kortuppgifter);
                break;
            case "personuppgifter":
                personuppgifter.update();
                baseFlowPane.getChildren().clear();
                baseFlowPane.getChildren().add(personuppgifter);
                break;
            case "betalning":
                betalning.update();
                baseFlowPane.getChildren().clear();
                baseFlowPane.getChildren().add(betalning);
                break;
            case "bekräftelse":
                bekraftelse.updateList();
                baseFlowPane.getChildren().clear();
                baseFlowPane.getChildren().add(bekraftelse);
                break;
            default:
                break;
        }
    }







}