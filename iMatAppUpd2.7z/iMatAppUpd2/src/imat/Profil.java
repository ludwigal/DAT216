package imat;

import imat.Listener;
import imat.ProductPanel;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.layout.AnchorPane;
import se.chalmers.cse.dat216.project.IMatDataHandler;
import se.chalmers.cse.dat216.project.Product;
import javafx.scene.layout.FlowPane;
import se.chalmers.cse.dat216.project.ShoppingItem;

import java.io.IOException;
import java.util.List;

public class Profil extends AnchorPane {

    private IMatDataHandler iMatDataHandler = IMatDataHandler.getInstance();

    private Listener sub;
    @FXML
    FlowPane productsFlowPane;

    @FXML
    AnchorPane dummyPane;

    public Profil(Listener sub) {
        this.iMatDataHandler = iMatDataHandler;
        this.sub=sub;

        {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("NYprofil.fxml"));
            fxmlLoader.setRoot(this);
            fxmlLoader.setController(this);
            try {
                fxmlLoader.load();
            } catch (IOException exception) {
                throw new RuntimeException(exception);
            }

        }

    }

    @FXML
    public void tillbaka() {
        System.out.println("Swag");
        this.sub.profiltillbaka();
    }

    public void persPressed(){
        this.sub.persPressed();
    }

    public void profilePressed(){sub.profilePressed();}

    public void homepagePressed(){sub.homepagePressed();}

    public void kortuppgifterPressed(){
        sub.changePay();
    }

    public void historyPressed() {
        sub.historyPressed();
    }

}

