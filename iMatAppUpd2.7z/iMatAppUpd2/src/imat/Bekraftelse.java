package imat;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Label;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.FlowPane;
import se.chalmers.cse.dat216.project.IMatDataHandler;
import se.chalmers.cse.dat216.project.ShoppingCart;
import se.chalmers.cse.dat216.project.ShoppingItem;

import java.io.IOException;
import java.util.List;

public class Bekraftelse extends AnchorPane {

    @FXML
    private FlowPane bekFlowPane;
    private IMatDataHandler iMatDataHandler = IMatDataHandler.getInstance();

    private ShoppingCart cart = IMatDataHandler.getInstance().getShoppingCart();

    @FXML
    private Label totalBekLabel;

    @FXML
    private Label postkodLabel;

    @FXML
    private Label cityLabel;

    @FXML
    private Label adressLabel;

    private Listener sub;

    private double totalCost;
    public Bekraftelse(Listener sub) {
        this.sub=sub;

        {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("Bekräftelse.fxml"));
            fxmlLoader.setRoot(this);
            fxmlLoader.setController(this);
            try {
                fxmlLoader.load();
            } catch (IOException exception) {
                throw new RuntimeException(exception);
            }

            updateList();
        }
    }
    public void updateList()
    {
        System.out.println("here");
        bekFlowPane.getChildren().clear();

        double totalCost = 0;

        List<ShoppingItem> items = cart.getItems();
        for (int i = 0; i < items.size(); i++)
        {

            BekProdukt cartItem = new BekProdukt(items.get(i));
            bekFlowPane.getChildren().add(cartItem);
            this.totalCost += items.get(i).getTotal();

        }
        postkodLabel.setText(iMatDataHandler.getCustomer().getPostCode());
        cityLabel.setText(iMatDataHandler.getCustomer().getPostAddress());
        adressLabel.setText(iMatDataHandler.getCustomer().getAddress());
        totalBekLabel.setText("Total:" + String.valueOf(this.totalCost));
    }
    public void profilePressed(){sub.profilePressed();}

    public void homepagePressed(){sub.homepagePressed();}

}
