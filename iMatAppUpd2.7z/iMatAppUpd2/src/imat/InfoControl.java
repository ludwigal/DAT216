package imat;

public class InfoControl {
}
