package imat;

import javafx.fxml.FXMLLoader;
import javafx.scene.layout.FlowPane;
import se.chalmers.cse.dat216.project.IMatDataHandler;
import se.chalmers.cse.dat216.project.ShoppingCart;
import se.chalmers.cse.dat216.project.ShoppingItem;

import java.io.IOException;
import java.util.List;

public class LitenVarukorg {
    private Listener sub;

    private FlowPane productsFlowPane;

    private ShoppingCart cart = IMatDataHandler.getInstance().getShoppingCart();

    private double totalCost;


    public LitenVarukorg(Listener sub) {


        this.sub = sub;

        {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("LitenVarukorg.fxml"));
            fxmlLoader.setRoot(this);
            fxmlLoader.setController(this);
            try {
                fxmlLoader.load();
            } catch (IOException exception) {
                throw new RuntimeException(exception);
            }
        }
    }
        public void updateList()
        {
            productsFlowPane.getChildren().clear();

            double totalCost = 0;

            List<ShoppingItem> items = cart.getItems();
            for (int i = 0; i < items.size(); i++)
            {

                //ProductPanel cartItem = new ProductPanel(items.get(i), this);
                //productsFlowPane.getChildren().add(cartItem);
                this.totalCost += items.get(i).getTotal();

            }
            productsFlowPane.getChildren().add(new BetalaKnapp(this.totalCost, this.sub));
    }
}