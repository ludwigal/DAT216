package imat;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import se.chalmers.cse.dat216.project.IMatDataHandler;
import se.chalmers.cse.dat216.project.Product;
import se.chalmers.cse.dat216.project.ShoppingItem;

import java.io.IOException;

public class BekProdukt extends AnchorPane {

    private ShoppingItem shoppingItem;

    @FXML
    ImageView imageView;
    @FXML
    Label nameLabel;

    @FXML Label amountLabel;
    @FXML Label prizeLabel;
    @FXML Label ecoLabel;

    @FXML Label totalLabel;

    private IMatDataHandler iMatDataHandler= IMatDataHandler.getInstance();

    private final static double kImageWidth = 100;
    private final static double kImageRatio = 0.75;

    public BekProdukt(ShoppingItem shoppingItem) {

        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("BekProdukt.fxml"));
        fxmlLoader.setRoot(this);
        fxmlLoader.setController(this);
        try {
            System.out.println("damn");
            fxmlLoader.load();

        } catch (IOException exception) {
            throw new RuntimeException(exception);
        }
        this.shoppingItem = shoppingItem;
        Product product = shoppingItem.getProduct();
        nameLabel.setText(product.getName());
        prizeLabel.setText(String.format("%.2f", product.getPrice()) + " " + product.getUnit());
        imageView.setImage(iMatDataHandler.getFXImage(product, kImageWidth, kImageWidth*kImageRatio));
        amountLabel.setText(String.valueOf((int) shoppingItem.getAmount()) + " st");
        //amountInCart.setText(String.valueOf((int) shoppingItem.getAmount()) + " st");
        totalLabel.setText(String.valueOf((int)shoppingItem.getTotal())+ " kr");
        if (!product.isEcological()) {
            ecoLabel.setText("");
        }

    }
}
