package imat;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Label;
import javafx.scene.layout.AnchorPane;

import java.io.IOException;


public class BetalaKnapp extends AnchorPane {


    private Listener sub;
    @FXML
    Label totalLabel;


    public BetalaKnapp(double totalcost, Listener sub) {
        this.sub = sub;
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("BetalaKnapp.fxml"));
        fxmlLoader.setRoot(this);
        fxmlLoader.setController(this);
        try {
            fxmlLoader.load();
        } catch (
                IOException exception) {
            throw new RuntimeException(exception);
        }
        totalLabel.setText("Pris: " + String.valueOf(totalcost) + " kr");
    }
    public void betala(){
        this.sub.betala();
    }
}
