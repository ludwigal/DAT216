package imat;

import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.*;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import se.chalmers.cse.dat216.project.IMatDataHandler;

import java.awt.*;
import java.io.IOException;

public class Kortuppgifter extends AnchorPane {

    private Listener sub;
    @FXML
    private TextField kortnummerField;

    @FXML
    private TextField cvcTextField;

    @FXML
    private ComboBox yComboBox;

    @FXML
    private ComboBox mComboBox;

    private IMatDataHandler iMatDataHandler = IMatDataHandler.getInstance();

    public Kortuppgifter(Listener sub) {
        this.sub = sub;
        {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("Kortuppgifter.fxml"));
            fxmlLoader.setRoot(this);
            fxmlLoader.setController(this);
            try {
                fxmlLoader.load();
            } catch (IOException exception) {
                throw new RuntimeException(exception);
            }
        }
        yComboBox.getItems().removeAll(yComboBox.getItems());
        yComboBox.getItems().addAll("2023", "2024", "2025", "2026");
        yComboBox.getSelectionModel().select("");

        mComboBox.getItems().removeAll(mComboBox.getItems());
        mComboBox.getItems().addAll("01", "02", "03", "04");
        mComboBox.getSelectionModel().select("");

        yComboBox.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<String>() {

            @Override
            public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
                iMatDataHandler.getCreditCard().setValidYear(Integer.parseInt(newValue));

            }
        });
        mComboBox.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<String>() {

            @Override
            public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
                iMatDataHandler.getCreditCard().setValidMonth(Integer.parseInt(newValue));

            }
        });
        kortnummerField.setText(iMatDataHandler.getCreditCard().getCardNumber());
        cvcTextField.setText(String.valueOf(iMatDataHandler.getCreditCard().getVerificationCode()));
        /*yComboBox.getItems().removeAll(yComboBox.getItems());
        yComboBox.getItems().addAll("2023", "2024", "2025", "2026", "2027", "2028");
        yComboBox.getSelectionModel().select("");
        yComboBox.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<String>() {

            @Override
            public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
                iMatDataHandler.getCreditCard().setValidYear(Integer.parseInt(yComboBox.getAccessibleText()));
                System.out.println(iMatDataHandler.getCreditCard().getValidYear());

            }


        });
*/

    }

    public void confirmPaymentMethod() {
        if (validkortnummer(kortnummerField.getText()) && validcvc(cvcTextField.getText())) {


            try {
                iMatDataHandler.getCreditCard().setCardNumber(kortnummerField.getText());
                iMatDataHandler.getCreditCard().setVerificationCode(Integer.parseInt(cvcTextField.getText()));


                // iMatDataHandler.getCreditCard().setValidMonth(Integer.parseInt(mComboBox.getAccessibleText()));
            } catch (Exception e) {
                System.out.println("Måste fylla i allt");
            }
            System.out.println(iMatDataHandler.getCreditCard().getCardNumber());
        } else {
            System.out.println("Måste fylla i allt");
        }


    }

    @FXML
    public void tillbaka() {
        System.out.println("Swag");
        this.sub.tillbaka();
    }

    public void profilePressed() {
        sub.profilePressed();
    }

    public Boolean validkortnummer(String kortnummer) {

        if (kortnummer.length() == 9) {
            return true;
        } else {
            return false;

        }
    }

    public Boolean validcvc(String cvc) {
        if (cvc.length() == 3) {
            return true;
        } else {
            return false;
        }
    }
    public void update(){
        iMatDataHandler.getCreditCard().setCardNumber(kortnummerField.getText());
        iMatDataHandler.getCreditCard().setVerificationCode(Integer.parseInt(cvcTextField.getText()));
    }

    public void homepagePressed(){sub.homepagePressed();}
}

    /*ResourceBundle bundle = java.util.ResourceBundle.getBundle("imat/resources/iMat");
    FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("Kortuppgifter.fxml"), bundle);
            fxmlLoader.setRoot(this);
                    backPane.getChildren().add(view);

*/