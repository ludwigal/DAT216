/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package imat;

import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import se.chalmers.cse.dat216.project.IMatDataHandler;
import se.chalmers.cse.dat216.project.Product;
import se.chalmers.cse.dat216.project.ShoppingItem;

import java.io.IOException;

/**
 *
 * @author oloft
 */
public class CartProductPanel extends AnchorPane {

    @FXML ImageView imageView;
    @FXML Label nameLabel;
    @FXML Label priceLabel;

    private MainPanel mainPanel;
    private IMatDataHandler iMatDataHandler = IMatDataHandler.getInstance();

    private Product product;

    private ShoppingItem shoppingItem;

    @FXML
    private Label amountLabel;

    private final static double kImageWidth = 50.0;
    private final static double kImageRatio = 0.75;

    public CartProductPanel(ShoppingItem shoppingItem, MainPanel mainPanel) {
        this.mainPanel = mainPanel;
        this.shoppingItem = shoppingItem;
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("CartProductPanel.fxml"));
        fxmlLoader.setRoot(this);
        fxmlLoader.setController(this);

        try {
            fxmlLoader.load();
        } catch (IOException exception) {
            throw new RuntimeException(exception);
        }

        this.product = shoppingItem.getProduct();
        nameLabel.setText(this.product.getName());
        priceLabel.setText(String.format("%.2f", this.product.getPrice()) + " " + this.product.getUnit());
        imageView.setImage(iMatDataHandler.getFXImage(this.product, kImageWidth, kImageWidth*kImageRatio));
        amountLabel.setText(String.valueOf((int)shoppingItem.getAmount()));
    }
    
    @FXML
    private void addToSelf() {

        System.out.println("swag");
        shoppingItem.setAmount(shoppingItem.getAmount() + 1);
        mainPanel.updateCart();

    }

    @FXML
    private void removeFromSelf(){

        System.out.println(shoppingItem.getAmount());

            if (shoppingItem.getAmount() <= 1)
            {
                removeSelf();
            }
            else
            {
                shoppingItem.setAmount(shoppingItem.getAmount() - 1);
                mainPanel.updateCart();
            }

    }
    public void removeSelf()
    {
        iMatDataHandler.getShoppingCart().removeItem(shoppingItem);
        mainPanel.updateCart();
    }


    @FXML
    protected void onClick(Event event){
        mainPanel.openProductView(product);
    }
}
