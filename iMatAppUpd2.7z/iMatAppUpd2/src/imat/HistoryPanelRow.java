package imat;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.FlowPane;
import se.chalmers.cse.dat216.project.*;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class HistoryPanelRow extends AnchorPane {

    private Order order;

    private HistoryPanel historyPanel;
    private IMatDataHandler iMatDataHandler = IMatDataHandler.getInstance();

    @FXML private Label historyDate;

    @FXML private FlowPane historyPanelRowFlowPane;

    private Map<String, ProductPanelMain> productPanelMap = new HashMap<String, ProductPanelMain>();

    public HistoryPanelRow(Order order, HistoryPanel historyPanel) {
        this.order = order;
        this.historyPanel = historyPanel;
        //System.out.println("swag");
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("HistoryPanelRow.fxml"));
        fxmlLoader.setRoot(this);
        fxmlLoader.setController(this);

        try {
            fxmlLoader.load();
        } catch (IOException exception) {
            throw new RuntimeException(exception);
        }
        historyDate.setText(Integer.toString(order.getDate().getYear()));
        for(ShoppingItem item : order.getItems()){
            historyPanelRowFlowPane.getChildren().add(new ProductPanelMain(item.getProduct(), null));
        }
    }
    @FXML private void placeListInShoppingCart(){
        for(ShoppingItem item : order.getItems()){
            iMatDataHandler.getShoppingCart().addProduct(item.getProduct());
        }
    }
}