package imat;

import se.chalmers.cse.dat216.project.IMatDataHandler;

public class Listener {
    private MainViewController subscriber;

    private IMatDataHandler iMatDataHandler = IMatDataHandler.getInstance();
    public Listener(MainViewController sub){
        this.subscriber = sub;
    }
    public void betala(){
        subscriber.fillcontent("betalning");
    }
    public void changePay(){
        subscriber.fillcontent("kortuppgfiter");
    }

    public void timeSet(String time){
        subscriber.timeSet(time);
    }

    public void profilePressed(){
        subscriber.fillcontent("profil");
        //System.out.println("hej");
    }

    public void varukorgPressed(){
        subscriber.fillcontent("cart");
    }

    public void homepagePressed(){subscriber.fillcontent("homepage");}

    public void profiltillbaka(){
        //System.out.println("Swag");
        subscriber.tillbakaView();
    }

    public void tillbaka(){
        //System.out.println("Swag");
        subscriber.tillbakaView();
    }

    public void bekPressed(){
        subscriber.fillcontent("bekräftelse");
    }

    public void persPressed(){
        subscriber.fillcontent("personuppgifter");
    }
    public void historyPressed(){
        subscriber.fillcontent("history");
    }
}
