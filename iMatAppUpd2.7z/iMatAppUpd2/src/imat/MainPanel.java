
package imat;

import java.io.IOException;
import java.net.URL;
import java.util.*;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.FlowPane;
import javafx.stage.Stage;
import se.chalmers.cse.dat216.project.*;


public class MainPanel extends AnchorPane {

    @FXML
    Label pathLabel;
    @FXML private AnchorPane productDetailsPane;
    @FXML private ImageView productDetailsImage;
    @FXML private Label productDetailsName;
    @FXML private Label productDetailsPrice;
    @FXML FlowPane productFlowPane;
    @FXML FlowPane shoppingCartFlowPane;

    @FXML
    private Button ShoppingCartLabel;

    @FXML ToggleButton startButton;

    @FXML
    private ToggleButton breadButton;

    @FXML
    private ToggleGroup categoryButtons;

    @FXML
    private Label categoryLabel;

    @FXML
    private Label totalLabel;

    @FXML
    private ToggleButton dairyButton;

    @FXML
    private ToggleButton drinkButton;

    @FXML
    private ToggleButton favouriteButton;

    @FXML
    private ToggleButton fishButton;

    @FXML
    private ToggleButton fruitButton;

    @FXML
    private ToggleButton meatButton;

    @FXML
    private ToggleButton pastaButton;

    @FXML
    private Button productDetailsBuyButton;


    @FXML
    private ScrollPane productListPane;

    @FXML
    private ToggleButton spiceButton;

    @FXML
    private ToggleButton sweetButton;

    @FXML
    private ToggleButton vegetableButton;

    @FXML
    private TextField searchTextField;

    @FXML Button searchButton;


    private Map<String, ProductPanelMain> productPanelMap = new HashMap<String, ProductPanelMain>();
    private Map<String, ProductPanelRow> productPanelRowMap = new HashMap<String, ProductPanelRow>();
    private Map<String, ProductPanelSubcategory> productPanelSubcategoryMap = new HashMap<String, ProductPanelSubcategory>();

    private Map<String, CartProductPanel> cartProductPanelMap = new HashMap<String, CartProductPanel>();
    private final static double kImageWidth = 100.0;
    private final static double kImageRatio = 0.75;

    private Product product;
@FXML
    private ToggleButton favouriteToggleButton;
@FXML
    private ToggleGroup favouriteToggleGroup;

    private Listener sub;

    private ShoppingCart cart = IMatDataHandler.getInstance().getShoppingCart();

    private double totalCost;


    IMatDataHandler iMatDataHandler = IMatDataHandler.getInstance();
    /*CreditCard creditCard = iMatDataHandler.getCreditCard();
    Customer customer = iMatDataHandler.getCustomer();
    ShoppingCart shoppingCart = iMatDataHandler.getShoppingCart();*/

    public MainPanel(Listener sub) {
        this.sub = sub;
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("MainPanel.fxml"));
        fxmlLoader.setRoot(this);
        fxmlLoader.setController(this);
        try {
            fxmlLoader.load();
        } catch (IOException exception) {
            throw new RuntimeException(exception);
        }
        ;
        categoryLabel.setText("Varor");

        String iMatDirectory = iMatDataHandler.imatDirectory();

        pathLabel.setText(iMatDirectory);

        List<ProductCategory> categories = List.of(ProductCategory.values());

        for (ProductCategory category : ProductCategory.values()) {
            //System.out.println(category);
            ProductPanelRow panelRow = new ProductPanelRow(category, this);
            ProductPanelSubcategory panelSubcategory = new ProductPanelSubcategory(category, this);
            //System.out.println("category");
            productPanelRowMap.put(String.valueOf(category), panelRow);
            productPanelSubcategoryMap.put(String.valueOf(category), panelSubcategory);
        }
        for (Product product : iMatDataHandler.getProducts()) {
            //System.out.println(product);
            ProductPanelMain panel = new ProductPanelMain(product, this);

            productPanelMap.put(String.valueOf(product), panel);
            System.out.println(String.valueOf(product));

        }
        //System.out.println(iMatDataHandler.getShoppingCart().getItems());
        List<ShoppingItem> items = cart.getItems();

        for (int i = 0; i != 3; i++){
            try {
                CartProductPanel cartPanel = new CartProductPanel((items.get(items.size() - i)), this);
                shoppingCartFlowPane.getChildren().add(cartPanel);
                cartProductPanelMap.put(String.valueOf(cartPanel), cartPanel);
            }
            catch(Exception e){
                System.out.println("swag");
            }
        }

        for (ShoppingItem item : iMatDataHandler.getShoppingCart().getItems()) {
            CartProductPanel cartPanel = new CartProductPanel(item, this);
            shoppingCartFlowPane.getChildren().add(cartPanel);
            cartProductPanelMap.put(String.valueOf(item), cartPanel);

        }
        updateProductListCategory(categories);
        totalLabel.setText("Total:" + String.valueOf((int)iMatDataHandler.getShoppingCart().getTotal()));

    }

    public void profilePressed(){
        sub.profilePressed();
    }
        //List<Product> products = iMatDataHandler.findProducts("s");
        /*for(Product product : products){
            iMatDataHandler.addProduct(product);
        }*/
        /*for(Product product : iMatDataHandler.getProducts()) {
            System.out.println(product);
            ProductPanel productListItem = new ProductPanel(product, this);
            productPanelMap.put(product.getName(), productListItem);
        }
        */






    Map<String, ProductPanelMain> getProductPanelMap(){
        return productPanelMap;
    }
    private void updateProductListCategory(List<ProductCategory> categories){
        productFlowPane.getChildren().clear();
        for (ProductCategory category : categories) {
            productFlowPane.getChildren().add(productPanelRowMap.get(String.valueOf(category)));
        }
    }
    private void updateProductListProduct(List<Product> products){
        productFlowPane.getChildren().clear();
        for (Product value : products) {
            productFlowPane.getChildren().add(productPanelMap.get(String.valueOf(value)));
        }


    }

    @FXML
    public void varukorgPressed(){
        this.sub.varukorgPressed();
    }
    void showSubcategory(ProductCategory category){

        List<ProductCategory>categoryList = List.of(category);
        updateProductListCategory(categoryList);
        productFlowPane.getChildren().clear();
        for (ProductCategory productCategory : categoryList) {
            productFlowPane.getChildren().add(productPanelSubcategoryMap.get(String.valueOf(productCategory)));
        }
        //productFlowPane.getChildren().clear();
        /*for(int i = 0; i < products.size(); i++){
            productFlowPane.getChildren().add(productPanelSubcategoryMap.get(String.valueOf(products.get(i))));
        }*/
    }


    public void openProductView(Product product) {
        this.product = product;
        populateProductDetailView(product);
        productDetailsPane.toFront();
    }
    @FXML
    public void closeProductView() {
        productListPane.toFront();
    }
    @FXML
    void toggleCategory(ActionEvent event) {
        List<ProductCategory> categories = new ArrayList<>();
        //List<Product> products = new ArrayList<>();
        if(event.getSource() == startButton){
            categories = List.of(ProductCategory.values());
            //products = iMatDataHandler.getProducts();
            //updateProductListProduct(products);
            categoryLabel.setText("Varor");
            //return;
        }
        else if(event.getSource() == favouriteButton){
            categoryLabel.setText("Favoriter");
            updateProductListProduct(iMatDataHandler.favorites());

            return;


        }
        else if(event.getSource() == vegetableButton){
            categories.add(ProductCategory.VEGETABLE_FRUIT);
            categories.add(ProductCategory.ROOT_VEGETABLE);
            categories.add(ProductCategory.CABBAGE);
            categories.add(ProductCategory.POD);
            categories.add(ProductCategory.NUTS_AND_SEEDS);
            categoryLabel.setText("Grönsaker");
        }
        else if(event.getSource() == fruitButton){
            categories.add(ProductCategory.FRUIT);
            categories.add(ProductCategory.BERRY);
            categories.add(ProductCategory.CITRUS_FRUIT);
            categories.add(ProductCategory.EXOTIC_FRUIT);
            categories.add(ProductCategory.MELONS);
            categoryLabel.setText("Frukt");
        }
        else if(event.getSource() == pastaButton){
            categories.add(ProductCategory.PASTA);
            categories.add(ProductCategory.POTATO_RICE);
            categoryLabel.setText("Pasta, Ris & Potatis");
        }
        else if(event.getSource() == breadButton){
            categories.add(ProductCategory.BREAD);
            categoryLabel.setText("Bröd");
        }
        else if(event.getSource() == dairyButton){
            categories.add(ProductCategory.DAIRIES);
            categoryLabel.setText("Mejeri & Ägg");
        }
        else if(event.getSource() == meatButton){
            categories.add(ProductCategory.MEAT);
            categoryLabel.setText("Kött & Fågel");
        }
        else if(event.getSource() == fishButton){
            categories.add(ProductCategory.FISH);
            categoryLabel.setText("Fisk & Skaldjur");
        }
        else if(event.getSource() == spiceButton){
            categories.add(ProductCategory.FLOUR_SUGAR_SALT);
            categories.add(ProductCategory.HERB);
            categoryLabel.setText("Kryddor");
        }
        else if(event.getSource() == sweetButton){
            categories.add(ProductCategory.SWEET);
            categoryLabel.setText("Sötsaker");
        }
        else if(event.getSource() == drinkButton){
            categories.add(ProductCategory.COLD_DRINKS);
            categories.add(ProductCategory.HOT_DRINKS);
            categoryLabel.setText("Dryck");
        }
        updateProductListCategory(categories);
    }

    @FXML private void handleFavouriteAction(ActionEvent event){
        if(iMatDataHandler.isFavorite(product)){
            iMatDataHandler.removeFavorite(product);
            System.out.println("No: " + product.getName());
        }
        else{
            iMatDataHandler.addFavorite(product);
            System.out.println("Yes: " + product.getName());
        }
    }

    private void populateProductDetailView(Product product) {
        productDetailsName.setText(product.getName());
        productDetailsImage.setImage(iMatDataHandler.getFXImage(product, kImageWidth, kImageWidth*kImageRatio));
        productDetailsPrice.setText(String.format("%.2f", product.getPrice()) + " " + product.getUnit());
        if(iMatDataHandler.isFavorite(product)){
            favouriteToggleGroup.selectToggle(favouriteToggleButton);
        }
        else{
            favouriteToggleGroup.selectToggle(null);
        }
    }

    @FXML
    void searchText(ActionEvent event){
        String text = searchTextField.getText();
        List<Product> foundProducts = iMatDataHandler.findProducts(text);
        updateProductListProduct(foundProducts);
        categoryButtons.selectToggle(null);
        categoryLabel.setText("Funna Varor");
    }
    @FXML
    private void handleAddAction(ActionEvent event) {
        System.out.println("Add " + product.getName());
        iMatDataHandler.getShoppingCart().addItem(new ShoppingItem(product));
        System.out.println(iMatDataHandler.getShoppingCart().getItems());
        System.out.println(iMatDataHandler.getShoppingCart().getTotal());
        updateCart();
    }
    void updateCart(){
        totalLabel.setText("Total:" + String.valueOf((int)iMatDataHandler.getShoppingCart().getTotal()));
        shoppingCartFlowPane.getChildren().clear();

        this.totalCost=0;

        List<ShoppingItem> items = cart.getItems();

        for (int i = 0; i != 4; i++){
            try {
                CartProductPanel cartPanel = new CartProductPanel((items.get(items.size() - i)), this);
                shoppingCartFlowPane.getChildren().add(cartPanel);
                cartProductPanelMap.put(String.valueOf(cartPanel), cartPanel);
            }
            catch(Exception e){
                System.out.println("swag");
            }
        }

    }

    @FXML
    protected void closeApplicationActionPerformed(ActionEvent event) throws IOException{
        System.out.println("hej");
        iMatDataHandler.shutDown();
        System.exit(0);
        //Stage iMatStage = (Stage) mainBorderPane.getScene().getWindow();
        //iMatStage.hide();
    }
}

