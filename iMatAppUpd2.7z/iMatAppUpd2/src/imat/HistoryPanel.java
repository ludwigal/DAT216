package imat;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.ToggleButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.FlowPane;
import se.chalmers.cse.dat216.project.IMatDataHandler;
import se.chalmers.cse.dat216.project.Order;
import se.chalmers.cse.dat216.project.Product;
import se.chalmers.cse.dat216.project.ProductCategory;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class HistoryPanel extends AnchorPane {
    private Map<String, HistoryPanelRowSmall> historyPanelRowSmallMap = new HashMap<String, HistoryPanelRowSmall>();
    private Map<String, HistoryPanelRow> historyPanelRowMap = new HashMap<String, HistoryPanelRow>();
    IMatDataHandler iMatDataHandler = IMatDataHandler.getInstance();

    private Listener sub;

    @FXML FlowPane historyFlowPane;
    @FXML AnchorPane historyAnchorPane;
    @FXML AnchorPane shoppingListAnchorPane;

    @FXML AnchorPane historyDetailPane;
    @FXML private ToggleButton purchaseHistoryButton;

    @FXML private ToggleButton shoppingListButton;

    @FXML private ToggleGroup toggleHistory;


    public HistoryPanel(Listener sub) {
        //toggleHistory.selectToggle(purchaseHistoryButton);
        this.sub = sub;
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("HistoryPanel.fxml"));
        fxmlLoader.setRoot(this);
        fxmlLoader.setController(this);
        try {
            fxmlLoader.load();
        } catch (IOException exception) {
            throw new RuntimeException(exception);
        }
        for (Order order : iMatDataHandler.getOrders()) {
            //System.out.println(product);
            HistoryPanelRowSmall panelRowSmall = new HistoryPanelRowSmall(order, this);
            HistoryPanelRow historyPanelRow = new HistoryPanelRow(order, this);

            historyPanelRowSmallMap.put(String.valueOf(order), panelRowSmall);
            historyPanelRowMap.put(String.valueOf(order), historyPanelRow);

        }
        System.out.println("Ordrar: " + String.valueOf(iMatDataHandler.getOrders()));
        updateHistoryList();
    }

    void updateHistoryList(){
        List<Order> orders = iMatDataHandler.getOrders();
        historyFlowPane.getChildren().clear();
        for (Order order : orders) {
            historyFlowPane.getChildren().add(historyPanelRowSmallMap.get(String.valueOf(order)));
            System.out.println(order);
        }
    }

    @FXML
    void ToggleHistoryList(ActionEvent event) {
        if(event.getSource() == purchaseHistoryButton){
            historyAnchorPane.toFront();
        }
        else if(event.getSource() == shoppingListButton){
            shoppingListAnchorPane.toFront();
        }
    }

    @FXML
    void openDetailedHistory(Order order){
        historyDetailPane.getChildren().clear();
        historyDetailPane.getChildren().add(historyPanelRowMap.get(String.valueOf(order)));
        historyDetailPane.toFront();
    }
    @FXML public void backToProfile() {
        sub.profiltillbaka();
    }
}

