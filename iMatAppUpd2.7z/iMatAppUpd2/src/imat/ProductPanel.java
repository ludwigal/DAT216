package imat;

import java.io.IOException;
import java.util.List;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import se.chalmers.cse.dat216.project.IMatDataHandler;
import se.chalmers.cse.dat216.project.Product;
import se.chalmers.cse.dat216.project.ShoppingCart;
import se.chalmers.cse.dat216.project.ShoppingItem;

/**
 *
 * @author oloft
 */
public class ProductPanel extends AnchorPane {

    @FXML ImageView imageView;
    @FXML Label nameLabel;

    @FXML Label amountLabel;
    @FXML Label prizeLabel;
    @FXML Label ecoLabel;

    @FXML
    public Label amountInCart;

    private IMatDataHandler iMatDataHandler= IMatDataHandler.getInstance();

    private Varukorg cart;
    private ShoppingItem shoppingItem;

    private final static double kImageWidth = 100;
    private final static double kImageRatio = 0.75;

    public ProductPanel(ShoppingItem shoppingItem, Varukorg cart) {
        this.cart=cart;
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("ProductPanel.fxml"));
        fxmlLoader.setRoot(this);
        fxmlLoader.setController(this);
        try {
            fxmlLoader.load();
        } catch (IOException exception) {
            throw new RuntimeException(exception);
        }

        this.shoppingItem = shoppingItem;
        Product product = shoppingItem.getProduct();
        nameLabel.setText(product.getName());
        prizeLabel.setText(String.format("%.2f", product.getPrice()) + " " + product.getUnit());
        imageView.setImage(iMatDataHandler.getFXImage(product, kImageWidth, kImageWidth*kImageRatio));
        amountLabel.setText(String.valueOf((int) shoppingItem.getAmount()) + " st");
        //amountInCart.setText(String.valueOf((int) shoppingItem.getAmount()) + " st");
        if (!product.isEcological()) {
            ecoLabel.setText("");
        }
    }
    public void addToSelf()
    {
        System.out.println("swag");
        shoppingItem.setAmount(shoppingItem.getAmount() + 1);
        cart.updateList();
        System.out.println(shoppingItem.getAmount());
    }
    public void removeFromSelf()
    {
        if (shoppingItem.getAmount() <= 1)
        {
            removeSelf();
        }
        else
        {
            shoppingItem.setAmount(shoppingItem.getAmount() - 1);
            cart.updateList();
        }
    }
    public void removeSelf()
    {
        iMatDataHandler.getShoppingCart().removeItem(shoppingItem);
        cart.updateList();
    }


}
