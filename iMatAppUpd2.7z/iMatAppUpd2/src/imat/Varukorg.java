package imat;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Label;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.VBox;
import se.chalmers.cse.dat216.project.IMatDataHandler;
import se.chalmers.cse.dat216.project.Product;
import javafx.scene.layout.FlowPane;
import se.chalmers.cse.dat216.project.ShoppingCart;
import se.chalmers.cse.dat216.project.ShoppingItem;

import java.io.IOException;
import java.util.List;

public class Varukorg extends AnchorPane {

    private ShoppingCart cart = IMatDataHandler.getInstance().getShoppingCart();

    private IMatDataHandler iMatDataHandler = IMatDataHandler.getInstance();

    private Listener sub;

    private double totalCost;
    @FXML
    FlowPane productsFlowPane;

    @FXML
    FlowPane swagPane;



    @FXML
    AnchorPane dummyPane;

    public Varukorg( Listener sub) {

        this.sub = sub;
        {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("Varukorg.fxml"));
            fxmlLoader.setRoot(this);
            fxmlLoader.setController(this);
            try {
                fxmlLoader.load();
            } catch (IOException exception) {
                throw new RuntimeException(exception);
            }
            updateList();
            loadForgot();

            }

        }

    public void betala(){
        sub.betala();
    }

    public void profilePressed(){sub.profilePressed();}

    public void homepagePressed(){sub.homepagePressed();}

    public void loadForgot(){
        swagPane.getChildren().add(new productgrej(iMatDataHandler.getProduct(43),this));
        swagPane.getChildren().add(new productgrej(iMatDataHandler.getProduct(44),this));
        swagPane.getChildren().add(new productgrej(iMatDataHandler.getProduct(45),this));
        swagPane.getChildren().add(new productgrej(iMatDataHandler.getProduct(46),this));

    }
    public void updateList()
    {
        productsFlowPane.getChildren().clear();

        this.totalCost=0;

        List<ShoppingItem> items = cart.getItems();
        for (ShoppingItem item : items) {

            ProductPanel cartItem = new ProductPanel(item, this);
            productsFlowPane.getChildren().add(cartItem);
            this.totalCost += item.getTotal();

        }
        productsFlowPane.getChildren().add(new BetalaKnapp(this.totalCost, this.sub));


    }
    public ShoppingCart getCart(){
        return cart;
    }

    @FXML
    public void tillbaka() {
        System.out.println("Swag");
        this.sub.tillbaka();
    }
}




    /*ResourceBundle bundle = java.util.ResourceBundle.getBundle("imat/resources/iMat");
    FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("Kortuppgifter.fxml"), bundle);
            fxmlLoader.setRoot(this);
                    backPane.getChildren().add(view);
*/

