package imat;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.AnchorPane;
import se.chalmers.cse.dat216.project.*;

import java.io.IOException;
import java.util.List;

public class HistoryPanelRowSmall extends AnchorPane {

    private Order order;

    private HistoryPanel historyPanel;
    private IMatDataHandler iMatDataHandler = IMatDataHandler.getInstance();

    @FXML private Label historyDate;

    @FXML private Button historyItemButton;

    public HistoryPanelRowSmall(Order order, HistoryPanel historyPanel) {
        this.order = order;
        this.historyPanel = historyPanel;
        //System.out.println("swag");
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("HistoryPanelRowSmall.fxml"));
        fxmlLoader.setRoot(this);
        fxmlLoader.setController(this);

        try {
            fxmlLoader.load();
        } catch (IOException exception) {
            throw new RuntimeException(exception);
        }
        historyDate.setText(Integer.toString(order.getDate().getYear()));

    }

    @FXML
    private void handleShowListAction() {
        historyPanel.openDetailedHistory(order);
        /*SubcategoryFlowPane.getChildren().clear();
        List<Product> products = mainViewController.iMatDataHandler.getProducts(this.category);
        for(int i = 0; i < products.size(); i++) {
            SubcategoryFlowPane.getChildren().add(productPanelMap.get(products.get(i).getName()));
        }*/
        System.out.println("Order");
        //historyPanel.showOrder(this.order);

        /*mainViewController.productFlowPane.getChildren().clear();
        SubcategoryFlowPane.getChildren().clear();
        List<Product> products = mainViewController.iMatDataHandler.getProducts(category);
        for(int i = 0; i < products.size(); i++) {
            SubcategoryFlowPane.getChildren().add(productPanelMap.get(products.get(i).getName()));
        }
        System.out.println("Show: " + category);
        SubcategoryLabel.setText(String.valueOf(category));*/
    }
}
