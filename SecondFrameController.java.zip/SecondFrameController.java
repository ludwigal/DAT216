package imat;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.scene.control.TextField;
import se.chalmers.cse.dat216.project.IMatDataHandler;

public class SecondFrameController implements Initializable{


    @FXML
    Button ProfileButton;
    @FXML
    TextField SearchPane;
    @FXML
    Button BuyHistoryButton;
    @FXML
    Button EarlierShoppingListButton;
    @FXML
    Button BackButton;
    @FXML
    Button BuyNewItemsButton;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle){
    }
}
