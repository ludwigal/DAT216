package imat;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;

import java.net.URL;
import java.util.ResourceBundle;

public class ThirdFrameController implements Initializable {

    @FXML
    Button ProfileButton;
    @FXML
    TextField SearchPane;
    @FXML
    Button BuyHistoryButton;
    @FXML
    Button BackButton;
    @FXML
    Button BuyNewItemsButton;
    @FXML
    ImageView logo;




    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

    }
}
